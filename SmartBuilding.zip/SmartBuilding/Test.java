package com.rishabh.SmartBuilding;

import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CharStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.TokenStream;

public class Test {

	public static void main(String[] args) throws RecognitionException {
		CharStream charStream=new ANTLRStringStream("AC IS AN APPLIANCE WITH PARAMETERS [CoolingLevel(0-40),temp(0-234)]" + 
				"TubeLight IS AN APPLIANCE WITH PARAMETERS [State(0-1)]" + 
				"Fan IS AN APPLIANCE WITH PARAMETERS [RPM(0-5000),MotorTemperature(0-200)]" + 
				"LightSensor IS AN APPLIANCE WITH PARAMETERS [AmbientLux(0-100000)]" +
				"L5 IS A BUILDING HAVING [AC(13),TubeLight(11)]" + 
				"JUP IS A BUILDING HAVING [TubeLight(11),AC(13),LightSensor(2)]"+
				"CONTROL temp OF JUP AC[2] AS 2000" +
				"CONTROL CoolingLevel OF JUP AC[2] AS 11" +
				"CONTROL CoolingLevel OF L5 AC[2] AS 202" +
				"CONTROL CoolingLevel OF L5 AC[5] AS 22" +
				"CONTROL CoolingLevel OF JUP AC[4] AS 180" +
				"CONTROL AmbientLux OF JUP LightSensor[1] AS 100"+
				"CONTROL RPM OF L5 Fan[1] AS 7000"+
				"SENSE CoolingLevel OF L5 AC[2]"+
				"SENSE CoolingLevel OF L5 AC[5]"+
				"SENSE CoolingLevel OF JUP AC[2]"+
				"SENSE CoolingLevel OF JUP AC[4]"+
				"SENSE RPM OF L5 Fan[1]"+
				"SENSE AmbientLux OF JUP LightSensor[1]");
		ControllerLexer lexer = new ControllerLexer(charStream);
		TokenStream tokenStream = new CommonTokenStream(lexer);
		ControllerParser parser = new ControllerParser(tokenStream);
		parser.rule();
		System.out.println("done");
	}

}

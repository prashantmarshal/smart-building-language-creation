package com.rishabh.SmartBuilding;

public class appliance {
	String[] param;               //name of the parameters
	String[] low;                 //lower range
	String[] high;                //upper range
	String[] value;
	int count=0;
	String name; 
	int id;
	appliance(appliance other)
	{
		this.param=new String[other.param.length];
		this.low=new String[other.param.length];
		this.high=new String[other.param.length];
		this.value=new String[other.param.length];
		for (int i=0;i<other.param.length;i++)
		{
			this.param[i]=new String();
			this.low[i]=new String();
			this.high[i]=new String();
			this.value[i]=new String();
			this.param[i]=other.param[i];
			this.low[i]=other.low[i];
			this.high[i]=other.high[i];
			this.value[i]="APPLIANCE is OFF,first SET its value to TURN it ON";
		}
		this.count=other.count;
		this.id=other.id;
		this.name=other.name;
	}
	
	/*public void setName(String num)
	{
		name=num;
		System.out.println("name changed");
	}*/
	appliance( String n,String[] st ,String[] val1,String[] val2)
	{
		name=n;
		int lon=st.length;
		param=new String[lon];
		low=new String[lon];
		high=new String[lon];
		//value=new String[lon];
		for (int i=0;i<st.length;i++)
		{
			
			param[i]=new String();
			low[i]=new String();
			high[i]=new String();
			//value[i]=new String();
			param[i]=st[i];		
			low[i]=val1[i];
			high[i]=val2[i];
			count++;
		}
	}
	public void getParam()
	{
		int i;
		for (i=0;i<param.length;i++)
		{
				System.out.println("parameter "+param[i]);
		}
	}	

}

package com.rishabh.SmartBuilding;
import java.util.*;



public class building {
	String[] appliancelist;              ///list of appliances in the building
	String[] number;                     //number of corresponding appliances
	ArrayList <appliance>installed=new ArrayList<appliance>();             
	String id;                       //name of the building
	int count=0;
	public void setId(String nam)
	{
		this.id=nam;
	}
	public String getId()
	{
		return id;
	}
	public void setPar(String[] st,String[] num)
	{
		int m=st.length;
		this.appliancelist=new String[m];
		this.number=new String[m];
		int i;
		for (i=0;i<m;i++)
		{
			this.appliancelist[i]=new String();
			this.appliancelist[i]=st[i];
			this.number[i]=new String();
			this.number[i]=num[i];
			count++;
		}
	}
	public void getlist()
	{ 
		int j;
		for (j=0;j<20;j++)
		{
			System.out.println("apliance name"+installed.get(j).id);
		}
	}
	public void setApp(ArrayList <appliance>al,int i)
	{
		
		for (int k=0;k<i;k++)
		{
			for (int j=0;j<al.size();j++)
			{
				if (this.appliancelist[k].compareToIgnoreCase(al.get(j).name)==0)
				{
					for (int p=1;p<=Integer.parseInt(this.number[k]);p++)
					{
						appliance a=new appliance(al.get(j));
						a.id=p;
						this.installed.add(a);
						count++;
					}
				}
			}
		}
		
		
	}

}
